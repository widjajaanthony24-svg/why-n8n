# why? for n8n

**Finds the runs n8n called successful that didn't actually do anything useful —
and, while you're building, tells you what your last change did to the output.**

n8n's Error Trigger fires when a node throws. It has nothing to say about a Code
node that returns `[]`, an extraction step that hands back an empty string, or an
agent that starts replying *"I'm sorry, I can't help with that"* where JSON
should be. Those runs are green. Everything after them silently doesn't happen.

No account, no API key, no SDK. It reads the n8n you're already signed into.

---

## While you're building

Open the panel on a workflow and press **Compare each run ▸**. Leave it open.
Every time you hit Execute:

```
run #418  vs  #417
3 changes in Build CRM Record
  tier         changed   "enterprise"  →  "mid-market"
  confidence   type      number  →  string "high"
  summary      shorter   144 chars  →  34 chars: "I'm sorry, I can't help…"
```

Or, just as usefully: **`Output identical to the previous run.`** — your change
did nothing.

n8n has no memory of your last run, so that comparison normally happens in your
head. Works from a workflow's second execution; no history or AI node needed.

## When something has already broken

Click the toolbar icon on the executions list:

```
#412  CT2 Contact Extract   extraction was empty → Build CRM Record produced nothing
                            first seen 3d ago   9/9 runs

#418  Lead Enrichment       Build CRM Record · confidence type — was number, now string "high"
                            summary shrank — was normally 144 chars, now 34:
                            "I'm sorry, I can't help with that."
```

## When an agent is confidently wrong

For AI nodes it separates the three cases that need different fixes:

| It says | It means |
|---|---|
| **bad context** | a tool errored, returned nothing, or came back about a different record — and it answered anyway |
| **wrong decision** | the answer contradicts the data it was given (`tier = mid-market, but its source says enterprise`) |
| **hallucinated** | the answer contains details that appear in nothing it was given |

Root cause beats symptom: if retrieval missed *and* the answer invented
something, it reports bad context — sending you to fix the prompt when the bug
is in the vector store wastes your afternoon.

It also lays out what the agent actually had to work with — which tools ran,
what they returned — from `intermediateSteps` when that's enabled, and from the
sub-nodes' own stored runs when it isn't.

**The honest limit:** a plausible answer that is simply *wrong*, from correct
data, needs to know the right answer. Nothing here can see that. What is
detectable is an answer contradicting its own source.

---

## Install

1. Download the latest `why-n8n-*.zip` from [Releases](../../releases), unzip it
2. Open `chrome://extensions`, turn on **Developer mode**
3. **Load unpacked** → select the unzipped folder
4. Open n8n → **Executions** → click the toolbar icon

Works unchanged on **Chrome, Edge, Brave, Arc, Opera and Vivaldi** — every API it
uses is standard Manifest V3. Firefox needs a small compatibility shim (not done
yet). Safari would need an Xcode conversion.

## What it looks for

Most of these need no AI node at all:

| | |
|---|---|
| **A field that wasn't there** | `{{ $json.customer.email }}` where the input has no `customer` — resolves to nothing, node runs, field goes out blank, run is green |
| **Produced nothing** | a node emitted zero items, or items that are entirely empty |
| **Named the cause** | which upstream field was blank — including keys inside JSON-in-a-string |
| **Error inside a 200** | the HTTP node is happy, the body says `rate limit exceeded` — expired tokens, throttling and validation failures all arrive this way |
| **Items lost mid-run** | 50 rows in, 47 out — three customers dropped and nobody noticed |
| **Shape drift** | output that no longer matches what this node normally produces |
| **Run-over-run diff** | what changed since the previous execution |
| **Sub-workflows** | when the fault is inside a child workflow, it says so and drills in |
| **Correlated failures** | several workflows breaking together, so you look for one shared cause |
| **How long** | how long a fault has been happening, across scans and sessions |

AI-only: the three-branch diagnosis, and invented details.

## If it gets something wrong

Every finding has a **✕**. One click and that node in that workflow is never
mentioned again — and the ignore list is one click to clear if you change your
mind. A tool that can't be silenced gets uninstalled instead.

There's also a **certain only** toggle. Some findings are facts about the run:
a node emitted nothing, an API said no, an expression pointed at a field that
wasn't there. Others are inferred from history: this output doesn't look like
it usually does. The inferences are where the value is *and* where crying wolf
would come from — so one click hides them and leaves only what's certain.

## What it deliberately does *not* flag

A tool that cries wolf gets uninstalled on day two. These are reported as the
workflow **working**:

- a Filter, Remove Duplicates, or Limit node that legitimately kept nothing
- an IF or Switch where the branch wasn't taken
- a trigger with nothing to hand on
- a node with fewer than 8 runs of history — drift refuses to judge thin evidence
- fields that were always varied
- **invented details on non-AI nodes** — a Code node minting an order reference
  is not hallucinating
- long prose reworded at a similar length between runs

Frequency is shown, never used to hide anything. A workflow broken for two days
looks identical to a poll that usually finds nothing; only the node *type* can
tell them apart, so type decides what gets demoted.

## It gets better the longer it's installed

Drift needs a node's own history before it will speak, so a workflow you built
this morning normally gets nothing. But what an OpenAI node emits doesn't change
between your workflows — so it learns per **node type** across your whole
instance, and a brand-new workflow is judged from its first run:

> *this workflow is too new to know itself — compared against 14 runs of
> `agent` elsewhere on this instance*

Pooled priors never punish a workflow for having a different shape: a field the
prior expects but this workflow doesn't use is ignored, not reported.

## Watching while you're not looking

The **watch** toggle checks in the background and puts a count on the toolbar
icon. But that stops when the browser does — MV3 service workers can't outlive
it.

Your n8n can. [`watcher/`](watcher/) is a workflow you import into your own
instance: same engine, every 15 minutes, messages Slack or Discord. No server,
no account, and no key handed to anyone — it calls your own n8n with your own
key. Needs API access, so self-hosted or a paid n8n Cloud plan.

## Privacy

Everything runs in your browser. No server, no telemetry, no account. Execution
payloads are read into memory to analyse and never transmitted. What's stored
locally: which faults were seen and when (keys and timestamps, no payload
content), your ignore list, and the learned node-type shapes.

## Security

Workflow definitions are treated as untrusted input, because n8n templates are
shared and imported freely:

- the replay URL is resolved and verified to stay under `/webhook/`, so a hostile
  template can't turn the replay button into a request against your n8n API
- every map keyed by payload fields is null-prototype — a field named
  `__proto__` would otherwise corrupt every object on the page
- payload recursion, width, and ids are bounded and validated

Found something? Open an issue. Security issues: please report privately first.

## Tests

No dependencies, no build step.

```bash
node tests/run-all.js
```

146 checks across 14 suites. Most of them are negatives — the cases where it
must stay quiet — because that's what decides whether a tool survives its first
week.

After changing `engine.js`, rebuild the watcher so the two can't drift apart:

```bash
node build-watcher.js
```

## Limits

- Chromium browsers only for now; Firefox needs a shim
- Reads the most recent 40 executions by default — *"look back further"* at the
  bottom of a scan goes to 100 or 250, at the cost of more requests to your n8n
- Shape drift needs 8+ prior runs of a node, or a learned prior for its type
- The three-branch diagnosis and invented-detail checks only apply to AI nodes
- The watcher needs n8n API access — self-hosted, or a paid Cloud plan

## Licence

MIT.
